// Cloudflare Worker — Makro Finder Image Proxy
// ดึงรูปสินค้าจริงจาก makro.pro ตาม Item No / Barcode แล้วส่งกลับเป็น JSON
// พร้อม CORS header ให้ GitHub Pages เรียกใช้ได้โดยตรง
//
// วิธี deploy (ฟรี):
// 1. เข้า https://dash.cloudflare.com -> Workers & Pages -> Create -> Create Worker
// 2. ตั้งชื่อ worker (เช่น makro-image-proxy) -> Deploy
// 3. กด Edit code แล้ววางโค้ดทั้งหมดนี้ทับของเดิม -> Deploy
// 4. จะได้ URL ประมาณ https://makro-image-proxy.<your-subdomain>.workers.dev
// 5. เอา URL นั้นไปใส่ในตัวแปร IMAGE_PROXY_URL ในไฟล์ index.html ของ makro-finder

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'Content-Type': 'application/json',
      'Cache-Control': 'public, max-age=86400',
      ...CORS_HEADERS,
    },
  });
}

async function lookupImage(query) {
  const pageUrl = 'https://www.makro.pro/th/c/search?q=' + encodeURIComponent(query);
  const resp = await fetch(pageUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36',
      'Accept-Language': 'th,en;q=0.8',
    },
  });
  if (!resp.ok) return null;
  const html = await resp.text();
  const match = html.match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/);
  if (!match) return null;
  let data;
  try {
    data = JSON.parse(match[1]);
  } catch (e) {
    return null;
  }
  const hits = data?.props?.pageProps?.initialSearchResult?.hits || [];
  return hits;
}

function pickBestHit(hits, itemNo, barcode) {
  if (!hits || !hits.length) return null;
  let best = hits.find((h) => String(h.document?.makroId || '') === String(itemNo));
  if (!best && barcode) {
    best = hits.find((h) => (h.document?.itemBarCodes || []).includes(barcode));
  }
  if (!best) best = hits[0];
  return best;
}

export default {
  async fetch(request) {
    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: CORS_HEADERS });
    }

    const url = new URL(request.url);
    const itemNo = (url.searchParams.get('itemNo') || '').trim();
    const barcode = (url.searchParams.get('barcode') || '').trim();

    if (!itemNo && !barcode) {
      return jsonResponse({ image: null, error: 'missing itemNo/barcode' }, 400);
    }

    try {
      // ลองค้นด้วย Item No ก่อน เพราะตรงกับฟิลด์ makroId ของ makro.pro
      let hits = itemNo ? await lookupImage(itemNo) : null;
      let best = pickBestHit(hits, itemNo, barcode);

      // ถ้าไม่เจอ ลองค้นด้วย barcode แทน
      if ((!best || !best.document?.images?.length) && barcode) {
        hits = await lookupImage(barcode);
        best = pickBestHit(hits, itemNo, barcode);
      }

      const image = best?.document?.images?.[0] || null;
      const title = best?.document?.title || null;
      return jsonResponse({ image, title });
    } catch (err) {
      return jsonResponse({ image: null, error: String(err) }, 200);
    }
  },
};
